# This is Prusa iteration 3
Published under GPL v3

All models are in the box_frame folder, including models for aluminium single plate. For some common configs we prepared models, see box_frame/sample_stls.

If you are looking for models that josefprusa uses in workshops, you need to go to https://github.com/josefprusa/Prusa3-vanilla
